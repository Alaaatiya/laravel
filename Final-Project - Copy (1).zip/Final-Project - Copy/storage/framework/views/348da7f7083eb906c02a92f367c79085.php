<?php $__env->startSection('title', 'All Category'); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .btn-soft-primary:hover {
            color: #1d1ad5;
        }

        .btn-soft-danger:hover {
            color: red;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(session('success')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">All Category</h4>
                    <p class="card-description"> All Category </p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th> Image </th>
                                    <th> Name </th>
                                    <th> Code </th>
                                    <th> Created_at </th>
                                    <th>Operations</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="py-1">
                                            <img src="<?php echo e(asset("admin/assets/images/categries/{$category->image}")); ?>"
                                                alt="image" />
                                        </td>
                                        <td> <?php echo e($category->name); ?> </td>
                                        <td> <?php echo e($category->code); ?> </td>
                                        <td> <?php echo e($category->created_at); ?> </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="<?php echo e(route('category.show', $category->code)); ?>" class="btn btn-soft-primary btn-sm"><i class="far fa-eye"></i></a>
                                                <a href="<?php echo e(route('category.edit', $category->code)); ?>"
                                                    class="btn btn-soft-primary btn-sm"><i class="fas fa-edit"></i></a>
                                                <form action="<?php echo e(route('category.destroy', $category->code)); ?>" method="POST">
                                                    <?php echo method_field("DELETE"); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="" style="border: none">
                                                        <a href="" class="btn btn-soft-danger btn-sm"><i
                                                                class="fas fa-trash-alt"></i></a>
                                                    </button>

                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="text-center">
                                        <td></td>
                                        <td></td>
                                        <td>No Data</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\depi\Final-Project\resources\views/admin/category/all.blade.php ENDPATH**/ ?>