<?php $__env->startSection('title', 'Edit Category'); ?>
<?php $__env->startSection("css"); ?>
<style>
    #imagePreview{
        width:300px;
        height:300px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Edit Category</h4>
                    <p class="card-description"> Edit Category </p>
                    <form class="forms-sample" action="<?php echo e(route('category.update' , $category->code)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputCode1">Code</label>
                            <input type="text" class="form-control" id="exampleInputCode1" placeholder="Code"
                                name="code" value="<?php echo e($category->code); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName1">Name</label>
                            <input type="text" class="form-control" id="exampleInputName1" placeholder="Name"
                                name="name" value="<?php echo e($category->name); ?>">
                        </div>
                        <div class="form-group">
                            <label>File upload</label>
                            <input type="file" id="imageUpload" name="image" class="file-upload-default" value="<?php echo e($category->image); ?>">
                            <div class="input-group col-xs-12 d-flex align-items-center">
                                <img id="imagePreview" src="<?php echo e(asset("admin/assets/images/categries/{$category->image}")); ?>"
                                                alt="image" />
                                <span class="input-group-append ms-2">
                                    <button class="file-upload-browse btn btn-primary" type="button">Upload New Image</button>
                                </span>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Submit</button>
                        <button class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        (function($) {
            'use strict';
            $(function() {
                $('.file-upload-browse').on('click', function() {
                    var file = $(this).parent().parent().parent().find('.file-upload-default');
                    file.trigger('click');
                });
                $('.file-upload-default').on('change', function() {
                    $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i,
                        ''));
                });
            });
        })(jQuery);
    </script>
    <script>
        document.getElementById('imageUpload').addEventListener('change', function(event) {
            const [file] = event.target.files;
            if (file) {
                document.getElementById('imagePreview').src = URL.createObjectURL(file);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\depi\Final-Project\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>