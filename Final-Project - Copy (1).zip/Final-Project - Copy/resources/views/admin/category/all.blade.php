@extends('layouts.dashboard.master')
@section('title', 'All Category')
@section('css')
    <style>
        .btn-soft-primary:hover {
            color: #1d1ad5;
        }

        .btn-soft-danger:hover {
            color: red;
        }
    </style>
@endsection
@section('content')
    <div class="row">
        @if (session('success'))
            <div class="alert alert-success text-center">
                {{ session('success') }}
            </div>
        @endif
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">All Category</h4>
                    <p class="card-description"> All Category </p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th> Image </th>
                                    <th> Name </th>
                                    <th> Code </th>
                                    <th> Created_at </th>
                                    <th>Operations</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($categories as $category)
                                    <tr>
                                        <td class="py-1">
                                            <img src="{{ asset("admin/assets/images/categries/{$category->image}") }}"
                                                alt="image" />
                                        </td>
                                        <td> {{ $category->name }} </td>
                                        <td> {{ $category->code }} </td>
                                        <td> {{ $category->created_at }} </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="{{ route('category.show', $category->code) }}" class="btn btn-soft-primary btn-sm"><i class="far fa-eye"></i></a>
                                                <a href="{{ route('category.edit', $category->code) }}"
                                                    class="btn btn-soft-primary btn-sm"><i class="fas fa-edit"></i></a>
                                                <form action="{{ route('category.destroy', $category->code) }}" method="POST">
                                                    @method("DELETE")
                                                    @csrf
                                                    <button type="submit" class="" style="border: none">
                                                        <a href="" class="btn btn-soft-danger btn-sm"><i
                                                                class="fas fa-trash-alt"></i></a>
                                                    </button>

                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr class="text-center">
                                        <td></td>
                                        <td></td>
                                        <td>No Data</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                @endforelse

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
