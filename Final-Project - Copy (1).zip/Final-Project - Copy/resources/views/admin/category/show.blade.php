@extends('layouts.dashboard.master')
@section('title', 'Show Category')
@section("css")
<style>
    #imagePreview{
        width:300px;
        height:300px;
    }
</style>
@endsection
@section('content')
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Show Category</h4>
                    <p class="card-description"> Show Category </p>
                    <form class="forms-sample" action="{{ route('category.edit' , $category->code) }}" method="get"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="exampleInputCode1">Code</label>
                            <input type="text" class="form-control" id="exampleInputCode1" placeholder="Code" disabled
                                name="code" value="{{ $category->code}}">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName1">Name</label>
                            <input type="text" class="form-control" id="exampleInputName1" placeholder="Name" disabled
                                name="name" value="{{ $category->name}}">
                        </div>
                        <div class="form-group">
                            <label>Image</label>
                            <div class="input-group col-xs-12 d-flex align-items-center">
                                <img id="imagePreview" src="{{ asset("admin/assets/images/categries/{$category->image}") }}"
                                                alt="image" />

                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Edit</button>
                        <button class="btn btn-light">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
    <script>
        (function($) {
            'use strict';
            $(function() {
                $('.file-upload-browse').on('click', function() {
                    var file = $(this).parent().parent().parent().find('.file-upload-default');
                    file.trigger('click');
                });
                $('.file-upload-default').on('change', function() {
                    $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i,
                        ''));
                });
            });
        })(jQuery);
    </script>
    <script>
        document.getElementById('imageUpload').addEventListener('change', function(event) {
            const [file] = event.target.files;
            if (file) {
                document.getElementById('imagePreview').src = URL.createObjectURL(file);
            }
        });
    </script>
@endsection
