<?php

use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('admin.index');
})->name("dashboard");
Route::prefix("category")->name("category.")->group(function(){
    Route::get('all' , [CategoryController::class , "index"])->name("all");
    Route::get('create' , [CategoryController::class , "create"])->name("create");
    Route::post('store' , [CategoryController::class , "store"])->name("store");
    Route::get('{code}/edit' , [CategoryController::class , "edit"])->name("edit");
    Route::put('{code}/update' , [CategoryController::class , "update"])->name("update");
    Route::delete('{code}/destroy' , [CategoryController::class , "destroy"])->name("destroy");
    Route::get("{code}/show" , [CategoryController::class , "show"])->name("show");
});
