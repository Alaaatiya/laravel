<?php
namespace App\Http\Crud;
class File{
    public static function upload($filePath , $fileName){
        $fileNewName = $fileName->hashName();
        $fileName->move("admin\assets\images\\".$filePath, $fileNewName);
        return $fileNewName;
    }
    public static function delete($path , $fileName){
        $filePath = public_path("admin/assets/images/{$path}/{$fileName}");
        if (file_exists($filePath)) {
            return unlink($filePath);
        } else {
            return false;
        }
    }
}

