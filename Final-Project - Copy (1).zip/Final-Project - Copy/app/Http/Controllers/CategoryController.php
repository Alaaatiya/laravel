<?php

namespace App\Http\Controllers;

use App\Http\Crud\File;
use App\Http\Requests\CreateCategoryRequest;
use App\Models\Category;
use Illuminate\Container\Attributes\DB;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = Category::all();
        return view("admin.category.all" , compact("categories"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("admin.category.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CreateCategoryRequest $request)
    {
        $image = $request->file("image");
        $imageName = File::upload("categries" , $image);
        $data = $request->except("__token" , "image");
        $data['image'] = $imageName;
        Category::create($data);
        return redirect()->route("category.all")->with("success" , "Category Created Successfully");
    }

    /**
     * Display the specified resource.
     */
    public function show(string $code)
    {
        $category = Category::where("code" , $code)->FirstOrFail();
        return view("admin.category.show" , compact("category"));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $code)
    {
        $category = Category::where("code" , $code)->FirstOrFail();
        return view("admin.category.edit" , compact("category"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $code)
    {
        $data = $request->except("_token" , "image" , "_method");
        $oldImage = Category::where("code" , $code)->FirstOrFail();
        if(! isset($request->image)){
            $data['image'] = $oldImage->image;
        }else{
            File::delete("categries" , $oldImage->image);
            $image = $request->file("image");
            $imageName = File::upload("categries" , $image);
            $data['image'] = $imageName;
        }
        Category::where("code" , $code)->update($data);
        return redirect()->route("category.all")->with("success" , "Category Updated Successfully");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $code)
    {
        $oldImage = Category::where("code" , $code)->FirstOrFail();
        File::delete("categries" , $oldImage->image);
        Category::where("code" , $code)->delete();
        return redirect()->route("category.all")->with("success" , "Category deleted Successfully");
    }
}
