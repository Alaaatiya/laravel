<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateCategoryRequest extends FormRequest{
    public function rules(){
        return [
            "code" => "required|max:30|min:5|regex:/^[0-9]{1,2}[A-Za-z]{2,}$/",
            "name" => "required|string|between:2,150",
            "image" => "required|mimes:jpeg,png,jpg|max:2048"   //2 mb
        ];
    }
}

